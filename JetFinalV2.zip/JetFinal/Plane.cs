﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JetFinal
{
     class Plane
    {
        protected int health;
        protected int speed;
        public string attack_direction;
        protected int attack_damage;


        public virtual void Attack()
        {

        }
    }
    
}
