﻿namespace JetFinal
{
    partial class JetGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JetGame));
            this.RegEnemy_Image = new System.Windows.Forms.PictureBox();
            this.Bullet_Image = new System.Windows.Forms.PictureBox();
            this.Hero = new System.Windows.Forms.PictureBox();
            this.txtScore = new System.Windows.Forms.Label();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.RegEnemy_Image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bullet_Image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Hero)).BeginInit();
            this.SuspendLayout();
            // 
            // RegEnemy_Image
            // 
            this.RegEnemy_Image.Image = ((System.Drawing.Image)(resources.GetObject("RegEnemy_Image.Image")));
            this.RegEnemy_Image.Location = new System.Drawing.Point(445, 32);
            this.RegEnemy_Image.Margin = new System.Windows.Forms.Padding(4);
            this.RegEnemy_Image.Name = "RegEnemy_Image";
            this.RegEnemy_Image.Size = new System.Drawing.Size(100, 85);
            this.RegEnemy_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.RegEnemy_Image.TabIndex = 0;
            this.RegEnemy_Image.TabStop = false;
            // 
            // Bullet_Image
            // 
            this.Bullet_Image.Image = ((System.Drawing.Image)(resources.GetObject("Bullet_Image.Image")));
            this.Bullet_Image.Location = new System.Drawing.Point(445, 443);
            this.Bullet_Image.Margin = new System.Windows.Forms.Padding(4);
            this.Bullet_Image.Name = "Bullet_Image";
            this.Bullet_Image.Size = new System.Drawing.Size(7, 27);
            this.Bullet_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Bullet_Image.TabIndex = 1;
            this.Bullet_Image.TabStop = false;
            // 
            // Hero
            // 
            this.Hero.Image = ((System.Drawing.Image)(resources.GetObject("Hero.Image")));
            this.Hero.Location = new System.Drawing.Point(445, 478);
            this.Hero.Margin = new System.Windows.Forms.Padding(4);
            this.Hero.Name = "Hero";
            this.Hero.Size = new System.Drawing.Size(110, 98);
            this.Hero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Hero.TabIndex = 2;
            this.Hero.TabStop = false;
            // 
            // txtScore
            // 
            this.txtScore.AllowDrop = true;
            this.txtScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScore.Location = new System.Drawing.Point(16, 633);
            this.txtScore.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtScore.Name = "txtScore";
            this.txtScore.Size = new System.Drawing.Size(191, 49);
            this.txtScore.TabIndex = 3;
            this.txtScore.Text = "0";
            // 
            // gameTimer
            // 
            this.gameTimer.Tick += new System.EventHandler(this.MainGameTimerEvent);
            // 
            // JetGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(1157, 693);
            this.Controls.Add(this.Hero);
            this.Controls.Add(this.Bullet_Image);
            this.Controls.Add(this.RegEnemy_Image);
            this.Controls.Add(this.txtScore);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "JetGame";
            this.Text = "JetGame";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyIsDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KeyIsUp);
            ((System.ComponentModel.ISupportInitialize)(this.RegEnemy_Image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bullet_Image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Hero)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox RegEnemy_Image;
        private System.Windows.Forms.PictureBox Bullet_Image;
        private System.Windows.Forms.PictureBox Hero;
        private System.Windows.Forms.Label txtScore;
        private System.Windows.Forms.Timer gameTimer;
    }
}

